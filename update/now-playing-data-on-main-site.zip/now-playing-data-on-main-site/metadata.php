<?php 
	$nowplaying = file_get_contents("http://www.chriscountry.co.uk/myriad/output.txt");
	$playingnext = file_get_contents("http://www.chriscountry.co.uk/myriad/output2.txt");

echo "<ul id=\"nowplaying_list\">";

if (!empty($nowplaying)): ?>
	<li><i class="fa fa-music"></i> <?php echo $nowplaying; ?></li>
<?php else: ?>
	<!-- No "Now Playing" data could be found! :( -->
<?php endif; ?>
<?php if(!empty($playingnext)): ?>
	<li><i class="fa fa-forward"></i> <?php echo $playingnext; ?></li>
<?php else: ?>
	<!-- No "Playing Next" data could be found! :( -->
<?php endif;

echo "</ul>";
 ?>
