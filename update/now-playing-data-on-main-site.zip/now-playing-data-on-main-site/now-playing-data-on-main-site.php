<?php
/*
Plugin Name: Now Playing Data On Main Site
Plugin URI: http://www.fredbradley.co.uk/?utm_source=client&utm_medium=wordpress-plugin&utm_content=META&utm_campaign=wordpress-plugin
Description: Puts the now playing data on the main site!
Version: 1.8
Author: Fred Bradley
Author URI: http://www.fredbradley.co.uk/?utm_source=client&utm_medium=wordpress-plugin&utm_content=META&utm_campaign=wordpress-plugin
License: GPL
Copyright: Fred Bradley
*/
require("update-checker.php");

function fb_nowplaying_enqueues() {
	// But only do it if the page is "radioplayer",
	// we don't want to clog up the other pages with things they don't need!
	
	wp_enqueue_style( 'nowplaying-data', plugins_url('nowplaying.css', __FILE__), '', '0.9', 'all');
	
	// This one needs to be active all the time!
	// Because we want to use it on all the other pages of the website too! 
//	wp_enqueue_script('nowplaying-data', plugins_url('nowplaying.js', __FILE__));

}
add_action( 'wp_enqueue_scripts', 'fb_nowplaying_enqueues' );

add_action('wp_footer', 'fb_nowplaying_ajax');

function fb_nowplaying_ajax() { ?>
	<script type="text/javascript">
		function GetOnAir(){
			//Try to create the AJAX Object
			//*******************************
			function GetXmlHttpObject() {
				var xmlHttp=null;
				try {
		  			// Firefox, Opera 8.0+, Safari
		  			xmlHttp=new XMLHttpRequest();
		  		} catch (e) {
		  			// Internet Explorer
		  			try {
		    				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
		    			} catch (e) {
		    				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
		    			 }
		  		 }
			return xmlHttp;
			}
		        //Test to see if the browser created the object
			//**********************************************
			xmlHttp=GetXmlHttpObject()
			if (xmlHttp==null) {
		  		alert ("Your browser does not support AJAX!");
		  		return;
		  	}
			
			//Browser was able to create AJAX Object
			//**************************************
			var url="<?php echo plugins_url('metadata.php?'.time(), __FILE__); ?>" //added date to end of URL  as a hack for IE or it caches the results and doesnt refresh :(
			var id="nowplaying";
			xmlHttp.onreadystatechange=function(){
		        	//0=uninitialized, 1=loading,2=loaded,3=interactive,4=complete
		        	if (xmlHttp.readyState==4) {
		                	if (xmlHttp.status == 200) { //ok from server
		                        	document.getElementById(id).innerHTML=" " + xmlHttp.responseText;
		                	}
		                	else {
		                        	document.getElementById(id).innerHTML=" ";
		        		}
				}
				/* else if (xmlHttp.readyState==1) {
		                	document.getElementById(id).innerHTML=" ";
		        	}
		        	else if (xmlHttp.readyState==2){
		                	document.getElementById(id).innerHTML=" ";
		        	}*/
			};
			xmlHttp.open("GET",url,true);
			xmlHttp.send(null);
			//Repeat every 1000 miliseconds (1 Second)
			// 2000 milseconds = 2 seconds
			//*******************************
			setTimeout("GetOnAir()", 100000); // 10 seconds
		}
		 
		window.onload=function(){GetOnAir();}//call when everything has loaded
		
		
		jQuery("#omc-main").before('<div id="nowplaying">Loading...</div>');
		var id="nowplaying";
		var newtext = "<i class=\"fa-spin fa fa-spinner\"></i>";
		
		document.getElementById(id).innerHTML=" " + newtext;



jQuery(function () {
    var list_slideshow = jQuery("#nowplaying_list"),
        listItems = list_slideshow.children('li'),
        listLen = listItems.length,
        i = 0,
        changeList = function () {
            listItems.eq(i).fadeOut(1300, function () {
                i += 1;
                if (i === listLen) {
                    i = 0;
                }
                listItems.eq(i).fadeIn(1300);
            });
        };
    listItems.not(':first').hide();
    setInterval(changeList, 3000);
});


		
	</script>
<?php } ?>
