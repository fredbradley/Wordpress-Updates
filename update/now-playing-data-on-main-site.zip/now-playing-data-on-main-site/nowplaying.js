jQuery(".home-top").before('<p id="nowplaying">The Footer is next!</p>');
var id="nowplaying";
var newtext = "Hello!";
document.getElementById(id).innerHTML=" " + newtext;
