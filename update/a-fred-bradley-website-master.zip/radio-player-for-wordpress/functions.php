<?php
require_once("require_plugins/require_these_plugins.php");
// Add the image size of the Radio Player slider
// NB: If you have installed this after already adding media, then you should think about regenerating your thumbnails!
	add_image_size('radioplayer-slider', 352, 235, true);


if ( is_admin() ){ // admin actions
 // add_action( 'admin_menu', 'add_mymenu' );
  add_action( 'admin_init', 'register_radioplayer_options' );
} else {
  // non-admin enqueues, actions, and filters
}

// Function to force a our template if the page's slug = 'radioplayer'
function wpa3396_page_template( $page_template ) {
	if ( is_page( 'radioplayer' ) ) {
		$page_template = dirname( __FILE__ ) . '/template-radioplayer.php';
	}
	return $page_template;
}
add_filter( 'page_template', 'wpa3396_page_template',999 );


// Function to get recent posts and display them inside the 'Owl Carousel' format!
function get_recent_stories() {
	$recent_posts = wp_get_recent_posts();
	foreach($recent_posts as $apost) {
		echo "\n<!-- Slider Item: -->\n";
		echo "\t<a href=\"".get_permalink($apost['ID'])."\" target=\"_blank\">\n";
		echo "\t\t<p class=\"slide-title\">".$apost['post_title']."</p>\n\t\t\t";
		echo get_the_post_thumbnail($apost['ID'], 'radioplayer-slider', array('class'=>'radioplayer-slide'));
		echo "\n\t</a>\n";
	}
}

