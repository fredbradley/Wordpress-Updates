<!DOCTYPE html>
<html>
<head>
<!-- 
	The Basic Radio Console - v1.0.2
	http://oliverneedham.co.uk/basicradioconsole/
	Copyright (c) 2013 Oliver Needham;
-->

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title>Chris Country - Listen Live</title>	
    
    <link rel="shortcut icon" href="img/btnPlay.png" />	
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    
    <!-- Elusive icons font -->
	<link rel="stylesheet" href="fonts/elusive-iconfont-master/css/elusive-webfont.css">
	<!--[if lte IE 7]><script src="fonts/elusive-iconfont-master/lte-ie7.js"></script><![endif]-->
	
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>	
	<script src="build/mediaelement-and-player.min.js"></script>
	<link rel="stylesheet" href="build/mediaelementplayer.min.css" />
    
    <link rel="stylesheet" href="mainstyling.css" />
    <link rel="stylesheet" href="custom.css" />
</head>
<body>

<div id="container">
	<div id="logo">
		<img src="/wp-content/uploads/2013/03/563500_482791198436890_1946030228_n3-e1364256028800.jpg" alt="Chris Country" class="header_logo" />
	</div>
<?php 
	$fp = fsockopen("streaming.planetwideradio.com", 9250, $errno, $errstr, 1); //last param is timeout in seconds
	if (!$fp) {
	    echo "$errstr ($errno)<br />\n"; // radio offline
	} else { ?>
		<audio id="player" src="http://streaming.planetwideradio.com:9250/;" type="audio/mpeg" controls="controls" autoplay="true" preload="0"></audio>
    <?php fclose($fp); // radio OK
	} ?>

	<div id="content_container">
		<div id="onair">Loading...</div>
        <div id="social">
        	<iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.facebook.com%2Fchriscountryradio&amp;send=false&amp;layout=button_count&amp;width=110&amp;show_faces=false&amp;font&amp;colorscheme=light&amp;action=like&amp;height=21&amp;appId=325863067435562" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:110px; height:21px;" allowTransparency="true"></iframe>
        	<a href="https://twitter.com/share" class="twitter-share-button">Tweet</a>
        	<div class="g-plusone" data-size="medium"></div>
        </div>
        <div id="promos" class="cycle-slideshow" data-cycle-fx="scrollHorz" data-cycle-pause-on-hover="true" data-cycle-speed="200">
            <img src="slides/slide01.png" class="first" />
            <img src="slides/slide02.png" />
            <img src="https://fbexternal-a.akamaihd.net/safe_image.php?d=AQCGfkzattqDfBgf&w=377&h=197&url=https%3A%2F%2Ffbcdn-sphotos-d-a.akamaihd.net%2Fhphotos-ak-frc3%2Fq81%2Fs720x720%2F1517543_604852412897434_700463319_n.jpg&cfs=1" />
            <img src="https://fbcdn-sphotos-f-a.akamaihd.net/hphotos-ak-prn1/t1/1012358_604868432895832_1707083818_n.jpg" />
        </div>
        <div id="footer">
        	<p>Built from <a href="http://oliverneedham.co.uk/basicradioconsole/" target="_blank">The Basic Radio Console</a></p>
        	<p>&copy; 2013 <a href="http://www.chriscountry.co.uk" target="_blank">Chris Country</a></p>
        </div>
	</div><!-- /#content_container -->
    
</div><!-- /#container -->

<!-- Script for MediaElement.js -->
<script src="mediaelement-config.js"></script>

<!-- On Air Script -->
<SCRIPT TYPE="text/javascript" LANGUAGE="JavaScript">
function GetOnAir(){
	//Try to create the AJAX Object
	//*******************************
	function GetXmlHttpObject() {
		var xmlHttp=null;
		try {
  			// Firefox, Opera 8.0+, Safari
  			xmlHttp=new XMLHttpRequest();
  		} catch (e) {
  			// Internet Explorer
  			try {
    				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
    			} catch (e) {
    				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
    			 }
  		 }
	return xmlHttp;
	}
        //Test to see if the browser created the object
	//**********************************************
	xmlHttp=GetXmlHttpObject()
	if (xmlHttp==null) {
  		alert ("Your browser does not support AJAX!");
  		return;
  	}
	
	//Browser was able to create AJAX Object
	//**************************************
	var url="metadata.php";//added date to end of URL  as a hack for IE or it caches the results and doesnt refresh :(
	var id="onair";
	xmlHttp.onreadystatechange=function(){
        	//0=uninitialized, 1=loading,2=loaded,3=interactive,4=complete
        	if (xmlHttp.readyState==4) {
                	if (xmlHttp.status == 200) { //ok from server
                        	document.getElementById(id).innerHTML=" " + xmlHttp.responseText;
                	}
                	else {
                        	document.getElementById(id).innerHTML=" ";
        		}
		}
		/* else if (xmlHttp.readyState==1) {
                	document.getElementById(id).innerHTML=" ";
        	}
        	else if (xmlHttp.readyState==2){
                	document.getElementById(id).innerHTML=" ";
        	}*/
	};
	xmlHttp.open("GET",url,true);
	xmlHttp.send(null);
	//Repeat every 1000 miliseconds (1 Second)
	// 2000 milseconds = 2 seconds
	//*******************************
	setTimeout("GetOnAir()", 60000); // 6 seconds
}
 
window.onload=function(){GetOnAir();}//call when everything has loaded
</script>

<!-- jQuery Cycle Plugin -->
<script src="http://malsup.github.com/jquery.cycle2.js"></script>

<!-- Twitter Widget Code -->
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="http://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

<!-- Google+ Code -->
<script type="text/javascript">
  window.___gcfg = {lang: 'en-GB'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>

</body>
</html>

