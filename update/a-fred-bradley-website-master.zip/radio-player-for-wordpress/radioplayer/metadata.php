<?php 

	$nowplaying = file_get_contents("http://www.chriscountry.co.uk/myriad/output.txt");
	$playingnext = file_get_contents("http://www.chriscountry.co.uk/myriad/output2.txt");

if (!empty($nowplaying)): ?>
	<p>&nbsp;</p>
	<p id="song"><i class="fa fa-music"></i> <?php echo $nowplaying; ?></p>
<?php else: ?>
	<!-- No "Now Playing" data could be found! :( -->
<?php endif; ?>
<?php if(!empty($playingnext)): ?>
	<p>&nbsp;</p>
	<p><i class="fa fa-forward"></i> <?php echo $playingnext; ?></p>
<?php else: ?>
	<!-- No "Playing Next" data could be found! :( -->
<?php endif; ?>
