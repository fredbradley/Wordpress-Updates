<?php
/*
Plugin Name: Radio Player For Wordpress
Plugin URI: http://www.fredbradley.co.uk/?utm_source=client&utm_medium=wordpress-plugin&utm_content=META&utm_campaign=wordpress-plugin
Description: Styles a RadioPlayer popup, and includes the piece of Javascript that is needed to show the link to listen! <strong>This is needed!</strong> <br /><strong>Warning: This plugin relies on you keeping the "myriad" folder named the same and in the same location!</strong> (You may need to "regenerate thumbnails", using a separate plugin in order for the thumbnails at the bottom of the radioplayer to be the correct size!)
Version: 1.8
Author: Fred Bradley
Author URI: http://www.fredbradley.co.uk/?utm_source=client&utm_medium=wordpress-plugin&utm_content=META&utm_campaign=wordpress-plugin
License: GPL
Copyright: Fred Bradley
*/


require_once("update-checker.php");

function chriscountry_setup() {
	// Load a specific functions file (similar to that in a theme)
	// NB: This loads AFTER the theme has been set up!
	require_once("functions.php");
	require_once("settings.php");

}
add_action( 'after_setup_theme', 'chriscountry_setup' );


// Function to get rid of the standard style sheet for the website
// (because we are going to use our own custom stylesheet!
function dequeue_stuff() {
	// If the page has a slug "radioplayer"
	if ( is_page( 'radioplayer' ) ) {
		wp_dequeue_style("theme_stylesheet");
		wp_deregister_style("theme_stylesheet");
		wp_dequeue_style("nowplaying-data");
		wp_deregister_style("nowplaying-data");	
	}
}
add_action( 'wp_print_styles', 'dequeue_stuff' );


// Now we can enqueue the new scripts and styles that we need for this plugin

function do_enqueues() {
	// But only do it if the page is "radioplayer",
	// we don't want to clog up the other pages with things they don't need!
	if ( is_page( 'radioplayer' ) ) {

		$path_uri = plugins_url('', __FILE__).'/radioplayer/';

		wp_enqueue_style( 'mediaelementplayer', $path_uri.'build/mediaelementplayer.min.css', '', 'olvr', 'all');
		wp_enqueue_style('owl', plugins_url('owl-carousel/owl-carousel/owl.carousel.css', __FILE__), '', 'owl', 'all');	
		wp_enqueue_style('owltheme', plugins_url('owl-carousel/owl-carousel/owl.theme.css', __FILE__), '', 'owltheme', 'all');
		wp_enqueue_style('fontawesome', '//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css', '', '4.1.0', 'all');
		wp_enqueue_style('main-styling', $path_uri.'mainstyling.css');
		wp_enqueue_style('custom-style', $path_uri.'custom.css');

		wp_enqueue_script( 'mediaelementjs', $path_uri.'build/mediaelement-and-player.min.js',array( 'jquery' ), 'olvr', false);
		wp_enqueue_script('owls', plugins_url('owl-carousel/owl-carousel/owl.carousel.js', __FILE__),array('jquery'),'owl',false);
	}
	
	// This one needs to be active all the time!
	// Because we want to use it on all the other pages of the website too! 
	wp_enqueue_script('radioplayer', plugins_url('radioplayer.js', __FILE__));

}
add_action( 'wp_enqueue_scripts', 'do_enqueues' );




