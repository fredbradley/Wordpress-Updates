/*
Script Name: Chris Country's Radio Player PopUp Javascript
Author: Fred Bradley
Author URI: http://www.fredbradley.co.uk/?utm_source=client&utm_medium=wordpress-plugin&utm_content=META&utm_campaign=wordpress-plugin
Copyright: Fred Bradley
*/
/*
Include this Javascript file somewhere in the <head> section of your web page!

eg: <script type="text/javascript" src="path/to/the/file/radioplayer.js"></script>

Then to insigate the code to listen live just include <script>embedChrisCountryLink();</script> at the location you wish for it to be placed!

*/
function popUpListen(title,ref) {
	var host = window.location.hostname;
	var path = window.location.pathname;
	var ref = host + path;

	props=window.open('http://www.chriscountry.co.uk/radioplayer?utm_source='+host+'&utm_medium=friends&utm_term='+host+'&utm_content='+host+'&utm_campaign=listen-live', 'poppage1', 'toolbars=0, scrollbars=0, location=0, statusbars=0, menubars=0, resizable=0, width=385, height=665, left=0, top=0, title='+title);
}


function embedChrisCountryLink(){
	var host = window.location.hostname;
	var path = window.location.pathname;
	var ref = host + path;
	
	document.write("<p><a href=\"javascript:popUpListen('Chris Country Radio Player')\">");
	document.write("<img src=\"http:\/\/www.chriscountry.co.uk\/wp-content\/uploads\/2013\/10\/LISTEN-LIVE-BUTTON.jpg\" alt=\"Listen live!\"><\/a><br \/>");
	document.write("<a href=\"http:\/\/www.chriscountry.co.uk\/listen-live\/\?utm_source="+ref+"&utm_medium=friends&utm_term="+ref+"&utm_content="+ref+"&utm_campaign=listen-live\">(Other ways to listen&#8230;)<\/a><\/p>");
}
