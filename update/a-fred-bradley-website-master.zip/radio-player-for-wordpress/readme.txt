=== Radio Player for Wordpress ===
Contributors: Fred Bradley
Tags: radioplayer, radio, audio, 
Donate link: http://www.fredbradley.co.uk/portfolio/radioplayer-for-wordpress
Requires at least: 3.0.0
Tested up to: 3.9.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Radio Player for Wordpress allows you to have a customised pop up radio player in your site. You can choose the stream, and change the style. 

== Description ==
Radio Player for Wordpress is a custom made Wordpress Plugin developed initially for the UK's number one Country Music Radio Station, "Chris Country". 

It's two main features are a Javascript file which you can include in your site (and share with others) so that your branded "listen live" popup button remains, and can be tracked where it is used. 

The second feature is of course the actually radio player page itself. Based upon the "Basic Radio Player Console" by Oliver Needham. 

== Screenshots ==
No Screenshots available just yet!

== Installation ==
Download the file, and upload as a plugin! 

== Frequently Asked Questions ==
Any questions, please direct to the developer: http://www.fredbradley.co.uk/contact

== Changelog ==

= 0.7 = 
* Added the TGM Required Plugins class to recommend the Force Regenerate Thumbnails plugin

= 0.6 = 
* Added Settings page to control stream, and Facebook Page

= 0.5 =
* Swapped out Cycle2 plugins (in the default Basic Radio Player Console package) for "Owl Carousel".
* Removed the Ellusive Web font
* Added the FontAwesome icon font, using via CDN

== Upgrade Notice ==
Upgrading to the latest version will allow you access to extra features, better functionality, and less bugs!