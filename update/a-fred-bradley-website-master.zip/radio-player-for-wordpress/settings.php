<?php
class MySettingsPage
{
    /**
     * Holds the values to be used in the fields callbacks
     */
    private $options;

    /**
     * Start up
     */
    public function __construct()
    {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    /**
     * Add options page
     */
    public function add_plugin_page()
    {
        // This page will be under "Settings"
        add_options_page(
            'Radio Player Settings', 
            'Radio Player', 
            'manage_options', 
            'radioplayer-settings', 
            array( $this, 'create_admin_page' )
        );
    }

    /**
     * Options page callback
     */
    public function create_admin_page()
    {
        // Set class property
        $this->options = get_option( 'radioplayer_options' );
        ?>
        <div class="wrap">
            <?php screen_icon(); ?>
            <h2>Radio Player Options</h2>           
            <form method="post" action="options.php">
            <?php
                // This prints out all hidden setting fields
                settings_fields( 'radioplayer-settings-group' );   
                do_settings_sections( 'radioplayer-settings' );
                submit_button(); 
            ?>
            </form>
        </div>
        <?php
    }

    /**
     * Register and add settings
     */
    public function page_init()
    {        
        register_setting(
            'radioplayer-settings-group', // Option group
            'radioplayer_options', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );

        add_settings_section(
            'settings_section_radioplayer_stramingserver', // ID
            'The Streaming Server', // Title
            array( $this, 'print_section_info' ), // Callback
            'radioplayer-settings' // Page
        );  

		add_settings_section(
			'settings_section_radioplayer_other',
			'Other Options',
			array($this, 'print_other_section_info'),
			'radioplayer-settings'
		);
        add_settings_field(
            'server_host', 
            'Server Host', 
            array( $this, 'host_callback' ), 
            'radioplayer-settings', 
            'settings_section_radioplayer_stramingserver'
        );

        add_settings_field(
            'server_port', // ID
            'Server Port Number', // Title 
            array( $this, 'server_port_callback' ), // Callback
            'radioplayer-settings', // Page
            'settings_section_radioplayer_stramingserver' // Section           
        );
        add_settings_field(
        	'server_mount',
        	'Mount (if no mount, please put a semi-colon in this box)',
        	array($this, 'server_mount_callback'),
        	'radioplayer-settings',
        	'settings_section_radioplayer_stramingserver'
        );      
  
		add_settings_field(
			'fb_page',
			'Facebook Page URL',
			array($this, 'fb_page_callback'),
			'radioplayer-settings',
			'settings_section_radioplayer_other'
		);
    }

    /**
     * Sanitize each setting field as needed
     *
     * @param array $input Contains all settings fields as array keys
     */
    public function sanitize( $input )
    {
        $new_input = array();
        if( isset( $input['server_port'] ) )
            $new_input['server_port'] = absint( $input['server_port'] );

        if( isset( $input['server_host'] ) )
            $new_input['server_host'] = sanitize_text_field( $input['server_host'] );

		if( isset( $input['fb_page'] ) )
            $new_input['fb_page'] = sanitize_text_field( $input['fb_page'] );
		
		if (isset($input['server_mount']))
			$new_input['server_mount'] = sanitize_text_field($input['server_mount']);
		
        return $new_input;
    }

    /** 
     * Print the Section text
     */
    public function print_section_info()
    {
        print '<hr /><p>Enter the settings for your streaming server below. <br /><strong>Please note, this plugin currently only works using the http:// protocol, which you do not need to include in your Server Host setting box!</strong></p><p>For Chris Country we use:</p><ul><li><strong>Server Host:</strong> streaming.planetwideradio.com</li><li><strong>Server Port: </strong>9250</li></ul>';
    }

    public function print_other_section_info()
    {
        print '<hr /><p>Please put in the FULL URL (including http://) of the Facebook page you wish to people to "Like"!</p><p><strong>NB:</strong> The other social media actions are automatically attributed to your wordpress homepage</p>';
    }

    /** 
     * Get the settings option array and print one of its values
     */
    public function server_port_callback()
    {
        printf(
            '<input type="text" id="server_port" name="radioplayer_options[server_port]" value="%s" />',
            isset( $this->options['server_port'] ) ? esc_attr( $this->options['server_port']) : ''
        );
    }
 /** 
     * Get the settings option array and print one of its values
     */
    public function server_mount_callback()
    {
        printf(
            '<input type="text" id="server_mount" name="radioplayer_options[server_mount]" value="%s" />',
            isset( $this->options['server_mount'] ) ? esc_attr( $this->options['server_mount']) : ''
        );
    }
	
    /** 
     * Get the settings option array and print one of its values
     */
    public function host_callback()
    {
        printf(
            '<input type="text" id="server_host" name="radioplayer_options[server_host]" value="%s" />',
            isset( $this->options['server_host'] ) ? esc_attr( $this->options['server_host']) : ''
        );
    }
    
    /** 
     * Get the settings option array and print one of its values
     */
    public function fb_page_callback()
    {
        printf(
            '<input type="text" id="fb_page" name="radioplayer_options[fb_page]" value="%s" />',
            isset( $this->options['fb_page'] ) ? esc_attr( $this->options['fb_page']) : ''
        );
    }
}

function register_radioplayer_options() {
	// Not sure, why but for anything other than local testing it seems I need this function, 
	// but it doesn't need to do anything!!
}

if( is_admin() )
    $my_settings_page = new MySettingsPage();