<?php
show_admin_bar(false);
$path_uri = plugins_url('', __FILE__).'/radioplayer/';
$path_abs = dirname( __FILE__ ).'/radioplayer/';
?>
<!-- <?php echo $path_abs; ?>  -->


<!DOCTYPE html>
<html>
<head>
<!-- 
	The Basic Radio Console - v1.0.2
	http://oliverneedham.co.uk/basicradioconsole/
	Copyright (c) 2013 Oliver Needham;
-->

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title><?php echo ($title = wp_title('–', false, 'right')) ? $title : ''; ?><?php echo ($description = get_bloginfo('description')) ? $description : bloginfo('name'); ?></title>	
    
    <link rel="shortcut icon" href="<?php echo $path_uri ?>img/btnPlay.png" />	
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
       
	<!-- Begin: Wordpress Head -->

    <?php wp_head(); ?>
    
    <!-- END: Wordpress Head -->
</head>
<body id="radioplayer">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<div id="container">
	<div id="logo">
		<?php the_post_thumbnail(array(175,175), array('class'=>'header_logo')); ?>
		
	</div>
<?php

	$rp_options = get_option('radioplayer_options');
	$fp = fsockopen($rp_options['server_host'], $rp_options['server_port'], $errno, $errstr, 1); //last param is timeout in seconds
	if (!$fp) {
		echo "<div class=\"error\"><div class=\"alert alert-info\"><p><strong>Whoops!</strong> $errstr ($errno)</p><p>Try again in a few seconds or <a href=\"http://www.chriscountry.co.uk/listen-live/\" target=\"_blank\">find an alternative way to listen</a></div></div>\n"; // radio offline
	} else { ?>
		<audio id="player" src="http://<?php echo $rp_options['server_host']; ?>:<?php echo $rp_options['server_port']; ?>/<?php echo $rp_options['server_mount']; ?>" type="audio/mpeg" controls="controls" autoplay="true" preload="0"></audio>
    <?php fclose($fp); // radio OK
	} ?>

	<div id="content_container">
		<p class="onairnow"><strong>On Air Now</strong></p>
		<p class="onairnow">Classic Country on Chris Country</p>
		<div id="nowplaying"><div style="margin:auto;text-align:center;display:block;"><i class="fa-spin fa-4x fa fa-spinner"></i></div></div>
        <div id="social">
        <?php $fb_page = urlencode($rp_options['fb_page']); ?>
        	<iframe src="//www.facebook.com/plugins/like.php?href=<?php echo $fb_page; ?>&amp;send=false&amp;layout=button_count&amp;width=110&amp;show_faces=false&amp;font&amp;colorscheme=light&amp;action=like&amp;height=21&amp;appId=325863067435562" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:110px; height:21px;" allowTransparency="true"></iframe>
        	
        	<a href="https://twitter.com/share" class="twitter-share-button" data-url="<?php site_url(); ?>" data-via="ChrisCountryUK" data-related="ChrisCountryUK,FredBradley" data-hashtags="CountryMusic">Tweet</a>
        	
        	<div class="g-plusone" data-href="<?php site_url(); ?>" data-size="medium"></div>
        </div>

		<div id="owl-slider" class="owl-carousel">
			<?php echo get_recent_stories(); ?>
		</div>
        
        <div class="radioplayer-footer">
        	<p>Adapted from <a href="http://oliverneedham.co.uk/basicradioconsole/" target="_blank">&quot;The Basic Radio Console&quot;</a> for Chris Country<br />by <a href="http://www.fredbradley.co.uk/" target="_blank">Fred Bradley</a></p>
        	<p>&copy; <?php echo date("Y"); ?> <a href="<?php site_url(); ?>" target="_blank">Chris Country</a></p>
        </div>
	</div><!-- /#content_container -->
</div><!-- /#container -->
<?php endwhile; endif; ?>
<!-- LOAD WORDPRESS FOOTER: -->
    <?php wp_footer(); ?>
<!-- END WORDPRESS FOOTER; -->

<!-- Script for MediaElement.js -->
<script src="<?php echo $path_uri; ?>mediaelement-config.js"></script>

<!-- On Air Script -->
<SCRIPT TYPE="text/javascript" LANGUAGE="JavaScript">
function GetOnAir(){
	//Try to create the AJAX Object
	//*******************************
	function GetXmlHttpObject() {
		var xmlHttp=null;
		try {
  			// Firefox, Opera 8.0+, Safari
  			xmlHttp=new XMLHttpRequest();
  		} catch (e) {
  			// Internet Explorer
  			try {
    				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
    			} catch (e) {
    				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
    			 }
  		 }
	return xmlHttp;
	}
        //Test to see if the browser created the object
	//**********************************************
	xmlHttp=GetXmlHttpObject()
	if (xmlHttp==null) {
  		alert ("Your browser does not support AJAX!");
  		return;
  	}
	
	//Browser was able to create AJAX Object
	//**************************************
	var url="<?php echo $path_uri; ?>metadata.php?<?php echo time();?>" //added date to end of URL  as a hack for IE or it caches the results and doesnt refresh :(
	var id="nowplaying";
	xmlHttp.onreadystatechange=function(){
        	//0=uninitialized, 1=loading,2=loaded,3=interactive,4=complete
        	if (xmlHttp.readyState==4) {
                	if (xmlHttp.status == 200) { //ok from server
                        	document.getElementById(id).innerHTML=" " + xmlHttp.responseText;
                	}
                	else {
                        	document.getElementById(id).innerHTML=" ";
        		}
		}
		/* else if (xmlHttp.readyState==1) {
                	document.getElementById(id).innerHTML=" ";
        	}
        	else if (xmlHttp.readyState==2){
                	document.getElementById(id).innerHTML=" ";
        	}*/
	};
	xmlHttp.open("GET",url,true);
	xmlHttp.send(null);
	//Repeat every 1000 miliseconds (1 Second)
	// 2000 milseconds = 2 seconds
	//*******************************
	setTimeout("GetOnAir()", 100000); // 10 seconds
}
 
window.onload=function(){GetOnAir();}//call when everything has loaded
</script>

<!-- Twitter Widget Code -->
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="http://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

<!-- Google+ Code -->
<script type="text/javascript">
  window.___gcfg = {lang: 'en-GB'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>

<!-- Owl Code -->
<script>
jQuery(document).ready(function() {

      jQuery("#owl-slider").owlCarousel({
        items : 1,
        autoPlay:true,
        mouseDrag:false,
        pagination:false,
        paginationSpeed:1000,
        slideSpeed:3000,
        rewindSpeed:2000,
      });

    });
</script>


</body>
</html>